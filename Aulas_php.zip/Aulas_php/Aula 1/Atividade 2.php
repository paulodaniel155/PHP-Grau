<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    //Iniciar variavel
    $numero1 = 5;
    $numero2 = 12;

    //Somar os números
    $soma = $numero1 + $numero2;

    //Exibir resultado
    echo "A soma de $numero1 e $numero2 é $soma";
    ?>
</body>
</html>