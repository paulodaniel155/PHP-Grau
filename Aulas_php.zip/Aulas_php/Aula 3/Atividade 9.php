<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        $idade = 16;

        if($idade > 18) {
            echo "Você é maior de idade.";
        } else {
            echo "Você é menor de idade.";
        }
    ?>
</body>
</html>