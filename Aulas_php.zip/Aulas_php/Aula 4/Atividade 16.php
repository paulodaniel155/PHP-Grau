<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        $cores = array("Vermelho", "Verde", "Azul"); 

        foreach ($cores as $cor) { 
            echo "Cor: $cor<br>"; 
        }
    ?>
</body>
</html>